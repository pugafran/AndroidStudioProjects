package es.informaticamovil.controldiabetes

import Product
import android.media.Image
import android.os.Parcel
import android.os.Parcelable
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AlimentosVM() : ViewModel(){
    data class Alimento(
        val nombre: String,
        val carbohidratos: Double,
        val indiceGlucemico: Int
    )

    var image: String = ""
    var totalCarbohidratos = 0.0;
    var totalIndiceGlucemicoPonderado = 0.0;
    var totalCarbohidratosPonderados = 0.0;
    var indiceGlucemico = 0;
    var product = Product();




    val jsonStr = """{
    "Altramuz": {"carbohidratos": 20, "indiceGlucemico": 15},
    "Arroz blanco, hervido": {"carbohidratos": 26.32, "indiceGlucemico": 70},
    "Arroz hinchado para desayuno": {"carbohidratos": 83.33, "indiceGlucemico": 85},
    "Arroz integral, hervido": {"carbohidratos": 25, "indiceGlucemico": 50},
    "Arroz salvaje, hervido": {"carbohidratos": 29.41, "indiceGlucemico": 35},
    "Arroz, cocido": {"carbohidratos": 26.32, "indiceGlucemico": 70},
    "Avena en copos": {"carbohidratos": 66.67, "indiceGlucemico": 40},
    "Boniato": {"carbohidratos": 20, "indiceGlucemico": 50},
    "Cebada, cocido": {"carbohidratos": 23.81, "indiceGlucemico": 45},
    "Centeno, cocido": {"carbohidratos": 26.31, "indiceGlucemico": 45},
    "Centeno, crudo": {"carbohidratos": 66.67, "indiceGlucemico": 45},
    "Cereales desayuno (trigo)": {"carbohidratos": 66.67, "indiceGlucemico": 77},
    "Cereales desayuno, ricos en fibra (>10%)": {"carbohidratos": 50, "indiceGlucemico": 50},
    "Cereales tipo muesli": {"carbohidratos": 66.67, "indiceGlucemico": 65},
    "Cuscús, cocido": {"carbohidratos": 22.22, "indiceGlucemico": 65},
    "Fideos de arroz, hervido": {"carbohidratos": 20, "indiceGlucemico": 50},
    "Galleta sin azúcar": {"carbohidratos": 55.55, "indiceGlucemico": 50},
    "Galleta tipo Digestiva": {"carbohidratos": 62.5, "indiceGlucemico": 65},
    "Galleta tipo María": {"carbohidratos": 66.67, "indiceGlucemico": 70},
    "Galleta tipo Príncipe": {"carbohidratos": 71.42, "indiceGlucemico": 70},
    "Garbanzo, en conserva": {"carbohidratos": 14.29, "indiceGlucemico": 35},
    "Garbanzo, hervido": {"carbohidratos": 18.18, "indiceGlucemico": 35},
    "Guisantes congelados, frescos, de lata": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Harina de cebada o centeno": {"carbohidratos": 58.82, "indiceGlucemico": 45},
    "Harina de maíz": {"carbohidratos": 66.67, "indiceGlucemico": 70},
    "Harina de soja": {"carbohidratos": 14.28, "indiceGlucemico": 25},
    "Harina de trigo": {"carbohidratos": 66.67, "indiceGlucemico": 78},
    "Judías blancas, en conserva": {"carbohidratos": 14.28, "indiceGlucemico": 35},
    "Judías blancas, hervido": {"carbohidratos": 18.18, "indiceGlucemico": 35},
    "Lentejas, en conserva": {"carbohidratos": 14.28, "indiceGlucemico": 35},
    "Lentejas, hervido": {"carbohidratos": 20, "indiceGlucemico": 35},
    "Maíz en lata": {"carbohidratos": 20, "indiceGlucemico": 65},
    "Mijo, cocido": {"carbohidratos": 18.87, "indiceGlucemico": 70},
    "Pan blanco (de trigo)": {"carbohidratos": 50, "indiceGlucemico": 70},
    "Pan de centeno": {"carbohidratos": 50, "indiceGlucemico": 65},
    "Pan de hamburguesa o Frankfurt": {"carbohidratos": 55.55, "indiceGlucemico": 85},
    "Pan de molde": {"carbohidratos": 50, "indiceGlucemico": 85},
    "Pan en bastoncitos": {"carbohidratos": 66.66, "indiceGlucemico": 70},
    "Pan rallado": {"carbohidratos": 66.66, "indiceGlucemico": 70},
    "Pan tostado o biscote": {"carbohidratos": 66.66, "indiceGlucemico": 70},
    "Pasta alimenticia integral, hervido": {"carbohidratos": 22.22, "indiceGlucemico": 45},
    "Pasta alimenticia, hervido": {"carbohidratos": 22.22, "indiceGlucemico": 50},
    "Patata, hervida": {"carbohidratos": 15.38, "indiceGlucemico": 65},
    "Patatas chips": {"carbohidratos": 5, "indiceGlucemico": 95},
    "Patatas fritas": {"carbohidratos": 3.33, "indiceGlucemico": 70},
    "Puré de patatas, elaborado con leche": {"carbohidratos": 1.25, "indiceGlucemico": 90},
    "Puré de patatas, en copos": {"carbohidratos": 6.67, "indiceGlucemico": 90},
    "Quinoa, hervido": {"carbohidratos": 20.83, "indiceGlucemico": 35},
    "Sémola de trigo, hervido": {"carbohidratos": 1.11, "indiceGlucemico": 67},
    "Soja seca, hervido": {"carbohidratos": 1, "indiceGlucemico": 15},
    "Sushi": {"carbohidratos": 22.22, "indiceGlucemico": 42},
    "Tapioca, cocido": {"carbohidratos": 30.3, "indiceGlucemico": 84},
    "Trigo sarraceno, hervido": {"carbohidratos": 23.81, "indiceGlucemico": 40},
    "Trigo tierno, hervido": {"carbohidratos": 25.64, "indiceGlucemico": 54},
    "Cuajada": {"carbohidratos": 5.71, "indiceGlucemico": 35},
    "Helado sin azúcares añadidos": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Helado de crema": {"carbohidratos": 20, "indiceGlucemico": 60},
    "Helado de hielo": {"carbohidratos": 20, "indiceGlucemico": 65},
    "Kéfir": {"carbohidratos": 5, "indiceGlucemico": 35},
    "Leche condensada": {"carbohidratos": 50, "indiceGlucemico": 61},
    "Leche desnatada": {"carbohidratos": 5, "indiceGlucemico": 32},
    "Leche en polvo": {"carbohidratos": 40, "indiceGlucemico": 30},
    "Leche entera": {"carbohidratos": 5, "indiceGlucemico": 27},
    "Leche semidesnatada": {"carbohidratos": 5, "indiceGlucemico": 30},
    "Queso fresco": {"carbohidratos": 4, "indiceGlucemico": 35},
    "Queso tipo Petit suisse": {"carbohidratos": 13.33, "indiceGlucemico": 40},
    "Yogur desnatado, de sabores o fruta": {"carbohidratos": 6.67, "indiceGlucemico": 35},
    "Yogur entero, de sabores o fruta": {"carbohidratos": 14.29, "indiceGlucemico": 35},
    "Yogur líquido": {"carbohidratos": 14.29, "indiceGlucemico": 40},
    "Yogur natural entero o desnatado": {"carbohidratos": 5, "indiceGlucemico": 35},
    "Yogur tipo Actimel": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Yogur tipo Actimel 0%": {"carbohidratos": 5, "indiceGlucemico": 35},
    "Aguacate": {"carbohidratos": 6.25, "indiceGlucemico": 10},
    "Albaricoque": {"carbohidratos": 6.67, "indiceGlucemico": 30},
    "Arándano": {"carbohidratos": 10, "indiceGlucemico": 25},
    "Castaña cruda": {"carbohidratos": 33.33, "indiceGlucemico": 65},
    "Castaña tostada": {"carbohidratos": 40, "indiceGlucemico": 65},
    "Cereza": {"carbohidratos": 10, "indiceGlucemico": 25},
    "Chirimoya": {"carbohidratos": 20, "indiceGlucemico": 35},
    "Ciruela": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Coco fresco": {"carbohidratos": 5, "indiceGlucemico": 45},
    "Coco seco": {"carbohidratos": 6.67, "indiceGlucemico": 45},
    "Dátil": {"carbohidratos": 66.67, "indiceGlucemico": 70},
    "Frambuesa": {"carbohidratos": 6.67, "indiceGlucemico": 25},
    "Fresones": {"carbohidratos": 5, "indiceGlucemico": 25},
    "Granada": {"carbohidratos": 14.29, "indiceGlucemico": 35},
    "Grosella": {"carbohidratos": 5, "indiceGlucemico": 25},
    "Grosella negra": {"carbohidratos": 7.14, "indiceGlucemico": 15},
    "Higos": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Kiwi": {"carbohidratos": 10, "indiceGlucemico": 50},
    "Litchi": {"carbohidratos": 14.29, "indiceGlucemico": 50},
    "Mandarina": {"carbohidratos": 10, "indiceGlucemico": 30},
    "Mango": {"carbohidratos": 10, "indiceGlucemico": 50},
    "Manzana": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Manzana asada": {"carbohidratos": 20, "indiceGlucemico": 35},
    "Melocotón": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Melocotón en conserva": {"carbohidratos": 20, "indiceGlucemico": 35},
    "Melón": {"carbohidratos": 5, "indiceGlucemico": 60},
    "Membrillo": {"carbohidratos": 6.67, "indiceGlucemico": 35},
    "Moras": {"carbohidratos": 6.67, "indiceGlucemico": 25},
    "Naranja": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Nectarina": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Níspero": {"carbohidratos": 10, "indiceGlucemico": 55},
    "Papaya": {"carbohidratos": 8, "indiceGlucemico": 55},
    "Paraguayo": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Pera": {"carbohidratos": 10, "indiceGlucemico": 30},
    "Piña": {"carbohidratos": 10, "indiceGlucemico": 45},
    "Piña en conserva": {"carbohidratos": 11.76, "indiceGlucemico": 53},
    "Piña en su jugo": {"carbohidratos": 16.67, "indiceGlucemico": 50},
    "Plátano": {"carbohidratos": 20, "indiceGlucemico": 50},
    "Sandía": {"carbohidratos": 5, "indiceGlucemico": 75},
    "Uva": {"carbohidratos": 20, "indiceGlucemico": 45},
    "Acelga": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Ajo": {"carbohidratos": 25, "indiceGlucemico": 30},
    "Alcachofa": {"carbohidratos": 3.33, "indiceGlucemico": 20},
    "Apio": {"carbohidratos": 2, "indiceGlucemico": 15},
    "Berenjena": {"carbohidratos": 3.33, "indiceGlucemico": 20},
    "Brócoli": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Calabacín": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Calabaza": {"carbohidratos": 5, "indiceGlucemico": 75},
    "Cardo": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Cebolla": {"carbohidratos": 6.67, "indiceGlucemico": 15},
    "Col de Bruselas, Coliflor": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Edamame": {"carbohidratos": 10, "indiceGlucemico": 35},
    "Endibia": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Espárrago blanco en conserva": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Espárrago verde": {"carbohidratos": 2, "indiceGlucemico": 15},
    "Judía verde": {"carbohidratos": 4, "indiceGlucemico": 30},
    "Lechuga": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Nabo": {"carbohidratos": 3.33, "indiceGlucemico": 30},
    "Palmitos": {"carbohidratos": 5, "indiceGlucemico": 20},
    "Pepino": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Pimiento rojo/verde": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Puerro": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Rábano": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Remolacha": {"carbohidratos": 6.67, "indiceGlucemico": 30},
    "Repollo": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Setas": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Soja en brotes": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Tomate": {"carbohidratos": 3.33, "indiceGlucemico": 30},
    "Zanahoria": {"carbohidratos": 6.67, "indiceGlucemico": 30},
    "Zanahoria hervida": {"carbohidratos": 5, "indiceGlucemico": 85},
    "Aceituna": {"carbohidratos": 4, "indiceGlucemico": 15},
    "Albaricoque seco": {"carbohidratos": 66.67, "indiceGlucemico": 35},
    "Almendra": {"carbohidratos": 6.67, "indiceGlucemico": 15},
    "Almendra tostada": {"carbohidratos": 7.14, "indiceGlucemico": 15},
    "Avellana": {"carbohidratos": 6.67, "indiceGlucemico": 15},
    "Cacahuete": {"carbohidratos": 10, "indiceGlucemico": 15},
    "Ciruela pasa": {"carbohidratos": 66.67, "indiceGlucemico": 40},
    "Dátil seco": {"carbohidratos": 66.67, "indiceGlucemico": 70},
    "Higo seco": {"carbohidratos": 66.67, "indiceGlucemico": 40},
    "Nuez": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Piñón": {"carbohidratos": 3.33, "indiceGlucemico": 15},
    "Pipas": {"carbohidratos": 12.5, "indiceGlucemico": 35},
    "Pistacho": {"carbohidratos": 12.5, "indiceGlucemico": 15},
    "Uva pasa": {"carbohidratos": 66.67, "indiceGlucemico": 65},
    "Bebida de almendra": {"carbohidratos": 5.0, "indiceGlucemico": 35},
    "Bebida de arroz": {"carbohidratos": 5.0, "indiceGlucemico": 85},
    "Bebida de avena": {"carbohidratos": 5.0, "indiceGlucemico": 35},
    "Bebida de cacao": {"carbohidratos": 10.0, "indiceGlucemico": 34},
    "Bebida de soja": {"carbohidratos": 4.0, "indiceGlucemico": 30},
    "Bebida energética": {"carbohidratos": 12.5, "indiceGlucemico": 70},
    "Bebida isotónica": {"carbohidratos": 7.69, "indiceGlucemico": 78},
    "Bebida refrescante de sabores": {"carbohidratos": 5.0, "indiceGlucemico": 70},
    "Bebida refrescante tipo cola": {"carbohidratos": 10.0, "indiceGlucemico": 70},
    "Bitter": {"carbohidratos": 10.0, "indiceGlucemico": 70},
    "Cerveza": {"carbohidratos": 4.0, "indiceGlucemico": 110},
    "Cerveza sin alcohol": {"carbohidratos": 4.0, "indiceGlucemico": 110},
    "Tónica": {"carbohidratos": 10, "indiceGlucemico": 70},
    "Zumo de fruta": {"carbohidratos": 10.0, "indiceGlucemico": 60},
    "Zumo de fruta 'sin azúcar añadido'": {"carbohidratos": 4.0, "indiceGlucemico": 45},
    "Zumo de tomate": {"carbohidratos": 5.0, "indiceGlucemico": 35},
    "Palomitas": {"carbohidratos": 50, "indiceGlucemico": 85}
 
}"""

    var alimentos: List<Alimento> = cargarAlimentos(jsonStr);

    constructor(parcel: Parcel) : this() {

    }

    fun cargarAlimentos(jsonStr: String): List<Alimento> {
        val gson = Gson()
        val type = object : TypeToken<Map<String, Map<String, Any>>>() {}.type
        val rawMap: Map<String, Map<String, Any>> = gson.fromJson(jsonStr, type)
        return rawMap.map { (nombre, valores) ->
            Alimento(
                nombre = nombre,
                carbohidratos = (valores["carbohidratos"] as Number).toDouble(),
                indiceGlucemico = (valores["indiceGlucemico"] as Number).toInt()
            )
        }
    }





}